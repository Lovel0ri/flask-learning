# @Time: 2022/9/12 0:19
# @Author: 李树斌
# @File : setup.py
# @Software :PyCharm

from setuptools import setup

setup(
    name='vsearch',
    version='1.0.1',
    description='The Head First Pyhon Search Tools',
    author='HF Python 2e',
    author_email='hfpy2e@gmail.com',
    url = '',
    py_modules=['vsearch'],
)