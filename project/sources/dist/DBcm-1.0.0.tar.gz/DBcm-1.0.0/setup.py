# @Time : 2022/8/31  16:56
# @Author: 李树斌
# @File : setup.py
# @Software : PyCharm

from distutils.core import setup
setup(
    name    = 'DBcm',
    version = '1.0.0',
    py_modules = ['DBcm'],
    author = '冰冰', #作者
    author_email = '2697601945@qq.com',
    url = 'http://www.headfristlabs.com',
    description = 'A simple printer of ',#简介内容
)